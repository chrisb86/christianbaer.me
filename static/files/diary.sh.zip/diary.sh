#!/bin/sh

FILENAME="/media/daten/Ablage/diary"
COUNTDAYS=`cat $FILENAME | wc -l`

while [ $# -gt 0 ]; do    # Until you run out of parameters . . .
    case "$1" in
        -e|--edit)
            nano $FILENAME
            exit 0
        ;;
        -p|--print)
            cat $FILENAME
            exit 0
        ;;
        -s|--status)
            echo "Du führst das Tagebuch seit "$COUNTDAYS" Tagen."
            exit 0
        ;;
        *)
        
        ;;
    esac
    shift       # Check next set of parameters.
done

    echo "Du führst das Tagebuch seit "$COUNTDAYS" Tagen."
    echo
    echo "Was ist heute passiert?"
    echo "--------------------------------------------------------------------------------"
    read DIARYTEXT
    echo `date +%y%m%d%a`" |"$DIARYTEXT >> $FILENAME
